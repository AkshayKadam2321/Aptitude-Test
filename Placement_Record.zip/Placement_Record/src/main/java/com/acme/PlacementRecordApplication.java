package com.acme;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlacementRecordApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlacementRecordApplication.class, args);
	}

}
